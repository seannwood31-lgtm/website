# 🚀 Tab Lock Site — Deploy to Vercel (Free)

Complete website + Stripe backend, deployed in ~10 minutes.

---

## Step 1 — Push to GitHub

1. Go to [github.com](https://github.com) → click **New repository**
2. Name it `tablock-site`, make it **Private**, click Create
3. On your computer, open Terminal in this folder and run:

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/tablock-site.git
git push -u origin main
```

---

## Step 2 — Deploy on Vercel

1. Go to [vercel.com](https://vercel.com) → Sign up free with GitHub
2. Click **Add New Project** → Import your `tablock-site` repo
3. Click **Deploy** (no settings to change)
4. Vercel gives you a URL like `tablock-site.vercel.app`

---

## Step 3 — Add a Custom Domain (optional but recommended)

1. Buy a domain at [Namecheap](https://namecheap.com) (~$10/yr) e.g. `sportsbook-tablockpro.com`
2. In Vercel → your project → Settings → Domains → Add your domain
3. Follow Vercel's DNS instructions (takes ~5 min to go live)

---

## Step 4 — Add Environment Variables

In Vercel → your project → Settings → Environment Variables, add:

| Key | Value |
|---|---|
| `STRIPE_SECRET_KEY` | `sk_live_...` from Stripe Dashboard |
| `STRIPE_PRICE_ID` | `price_...` your $2.99/mo price ID |
| `STRIPE_WEBHOOK_SECRET` | `whsec_...` from Stripe webhook setup |
| `BASE_URL` | `https://yourdomain.com` (your Vercel URL) |

Then **Redeploy** your project for the vars to take effect.

---

## Step 5 — Set Up Stripe

1. Go to [dashboard.stripe.com](https://dashboard.stripe.com)
2. Products → Create Product: **"Tab Lock Pro"**
3. Add Price: **$2.99 / month recurring** → copy the `price_...` ID
4. Developers → Webhooks → Add endpoint:
   - URL: `https://yourdomain.com/api/webhook`
   - Events: `customer.subscription.deleted`, `customer.subscription.paused`, `customer.subscription.resumed`, `invoice.paid`
5. Copy the **Signing Secret** → add as `STRIPE_WEBHOOK_SECRET` in Vercel

---

## Step 6 — Set Up Vercel KV (database for licenses)

1. In Vercel dashboard → your project → **Storage** tab
2. Click **Connect Store** → **Create KV Database**
3. Click Connect — Vercel automatically adds the `KV_*` env vars

---

## Step 7 — Update your Extension

In `license.js` inside the extension, replace:
```js
const LICENSE_SERVER_URL = "https://yourdomain.com";
```
with your actual Vercel URL.

In `manifest.json`, replace:
```json
"https://yourdomain.com/*"
```
with your actual domain.

---

## Your Site Pages

| URL | Page |
|---|---|
| `/` | Home page — about the extension |
| `/pro` | Pricing + Stripe subscribe button |
| `/success` | Post-payment page showing license key |
| `/api/verify?key=TBLK-...` | License verification endpoint (called by extension) |

---

## That's it!

Your site is live, payments work, and the extension verifies licenses automatically.
